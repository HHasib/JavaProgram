/**Name: Abu Hasnat Hasib
 * CIS 1068
 * Section: 09
 * Instructor: John Fiore
 * Lab Instructor: Dodge Wyatt Hill
 * Assignment: 10
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

public class GuessGame {

    public static void main (String [] args) throws FileNotFoundException{
        readWords();
//        hangmanMain("tsktsks",8,"p");
        }

//this reads  from the text file for all the words
    public static void readWords() throws FileNotFoundException{
        // specifies the dictionary file from which the words are used
        File testFile = new File("big_word_list.txt");
        // Reads the contents of the dictionary file
        Scanner dict = new Scanner(testFile);
        //Creates an empty array
        ArrayList<String> words = new ArrayList<String>();
        //adds all the words int the dictionary to the array that was created
        while (dict.hasNextLine()) {
            String word = dict.nextLine();
            words.add(word);
        }
        //the length of the word is specified randomly
        int word_length = randLength(words);
//        int word_length = 10;
//        System.out.println(word_length);

        //removes all words from array that are not length of word_length
        int j = 0;
        while(j < words.size()){
            if (words.get(j).length() != word_length){
                words.remove(j);
            }
            else{
                j++;
            }
        }
//        System.out.println(words.size());
//        System.out.println(words);
        cheating(words);

    }
    //this is the cheating section of the game
    public static void cheating(ArrayList<String> words){

        //if all the words contain the letter choose a random word
        int score = 8;
        String mysteryWord = "";
        String input = "";
        Scanner entered = new Scanner(System.in);

        while(words.size() > 0){
            int j = 0;
            //takes input from user
            System.out.print("Enter your letter or word: ");
            input = entered.nextLine();
            // chooses a random word from remaining list
            //if the if function causes the arraylist to be empty the chosen word still remains
            // if it is not empty a new word is chosen from the new list
            Random rand = new Random();
            int index = rand.nextInt(words.size());
            mysteryWord = words.get(index);
            //removes the words if it contains the letter or string
            //iterates through all the words and remove those that contains the input
            while(j< words.size()) {
                if (words.get(j).contains(input)) {
//                    System.out.println(words.get(j) + " is removed");
                    words.remove(j);
                } else {
                    j++;
                }
            }
            if(words.size() > 0) {
                score--;
                System.out.println(input + " is not there in the word.");
                //comment out this section for the actual game
                System.out.println("(You can comment out this section) Remaining words" + words);
                System.out.println("Your score now stands: " + score);
            }
            if(score == 0){
                break;
            }

        }
//        System.out.println("Out of loop now. The mystery word is: " + mysteryWord);
        hangmanMain(mysteryWord, score, input);

    }

    public static void hangmanMain(String mysteryWord, int score, String input){

        String solvedWord = "";
        for(int j = 0; j<mysteryWord.length(); j++){
            solvedWord += "*";
        }

        Scanner entered = new Scanner(System.in);
        while(score > 0 ){

            int tracker = 0;

            for(int i = 0; i < mysteryWord.length(); i++) {
                String currentLetter = mysteryWord.substring(i, i + 1);
                if (input.equalsIgnoreCase(currentLetter)) {
                    solvedWord = solvedWord.substring(0, i) + input + solvedWord.substring(i + 1);
                    tracker++;
                }
            }

            /*
            if(mysteryWord.contains(input)){
                    int index = mysteryWord.indexOf(input);
                    solvedWord = solvedWord.substring(0,index) + input + solvedWord.substring(index+1);
                    tracker++;

            }

             */


            if(tracker == 0)
//            else if(!mysteryWord.contains(input))
            {
                score--;
                System.out.println(input + " is not there in the word.");
                System.out.println("Your score now stands: " + score);
            }
            if (!solvedWord.contains("*")) {
                break;
            }
            if (score > 0) {
                System.out.println("SolvedWord: " + solvedWord);
                //takes user input
                System.out.print("Enter your letter or word: ");
                input = entered.nextLine();
            }

        }
        if(score > 0) {
            System.out.println("Congratz! You win.");
        }
        else{
            System.out.println("You lose");
        }
        System.out.println("The word was: " + mysteryWord);
        System.out.println("Your word is: " + solvedWord);
        System.out.println("Your score is: " + score);

    }

// this generates a random length of word that is to be chosen
    public static int randLength(ArrayList<String> words){
        //finds the length of largest and smallest words
        int RAND_MAX = words.get(0).length();
        int RAND_MIN = words.get(0).length();
        for(int i =1; i<words.size();i++){
            if(words.get(i).length() > RAND_MAX){
                RAND_MAX = words.get(i).length();
            }
            if(words.get(i).length() < RAND_MIN){
                RAND_MIN = words.get(i).length();
            }
        }
        Random rand = new Random();
        int randL = rand.nextInt(RAND_MAX-RAND_MIN)+ RAND_MIN; //returns a number between 1 and 14 for the small test file
        return randL;
    }
}
